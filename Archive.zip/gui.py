"""
GUI for the car park simulation using tkinter.
All controls are sliders/checkboxes with live-updating results.
"""

import tkinter as tk
from tkinter import ttk

from models import CarParkConfig, VehicleType, StaffConfig, ANPRConfig, OvernightConfig
from engine import run_simulation


class CarParkSimulatorGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Car Park Simulator - 64 Space Car Park")
        self.root.configure(bg="#1e1e2e")

        self.config = CarParkConfig()

        # Tkinter variables
        self.vars = {}

        self._build_ui()
        self._update_results()

    # ------------------------------------------------------------------ UI
    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("TFrame", background="#1e1e2e")
        style.configure("TLabel", background="#1e1e2e", foreground="#cdd6f4", font=("Helvetica", 10))
        style.configure("Header.TLabel", background="#1e1e2e", foreground="#f5c2e7", font=("Helvetica", 13, "bold"))
        style.configure("SubHeader.TLabel", background="#1e1e2e", foreground="#89b4fa", font=("Helvetica", 11, "bold"))
        style.configure("Result.TLabel", background="#1e1e2e", foreground="#a6e3a1", font=("Helvetica", 10))
        style.configure("Loss.TLabel", background="#1e1e2e", foreground="#f38ba8", font=("Helvetica", 10))
        style.configure("Big.TLabel", background="#1e1e2e", foreground="#f9e2af", font=("Helvetica", 14, "bold"))
        style.configure("Neutral.TLabel", background="#1e1e2e", foreground="#cdd6f4", font=("Helvetica", 10))
        style.configure("TCheckbutton", background="#1e1e2e", foreground="#cdd6f4", font=("Helvetica", 10))
        style.configure("TScale", background="#1e1e2e")
        style.configure("TSeparator", background="#45475a")

        # Main container with scroll
        canvas = tk.Canvas(self.root, bg="#1e1e2e", highlightthickness=0)
        scrollbar = ttk.Scrollbar(self.root, orient="vertical", command=canvas.yview)
        self.main_frame = ttk.Frame(canvas)

        self.main_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=self.main_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Bind mousewheel
        def _on_mousewheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_mousewheel)
        canvas.bind_all("<Button-4>", lambda e: canvas.yview_scroll(-3, "units"))
        canvas.bind_all("<Button-5>", lambda e: canvas.yview_scroll(3, "units"))

        # Two-column layout: controls left, results right
        left = ttk.Frame(self.main_frame)
        left.grid(row=0, column=0, sticky="nsew", padx=10, pady=10)
        right = ttk.Frame(self.main_frame)
        right.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)

        self._build_controls(left)
        self._build_results(right)

    def _make_slider(self, parent, label, from_, to_, default, resolution=1,
                     row=0, var_key=None, fmt=None):
        """Create a labeled slider that updates on change."""
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=2)

        var = tk.DoubleVar(value=default)
        if var_key:
            self.vars[var_key] = var

        val_label = ttk.Label(parent, text=self._format_val(default, fmt), width=10)
        val_label.grid(row=row, column=2, sticky="e", padx=(5, 0))

        def on_change(val):
            val_label.config(text=self._format_val(float(val), fmt))
            self._update_results()

        slider = ttk.Scale(parent, from_=from_, to=to_, variable=var,
                           orient="horizontal", length=250, command=on_change)
        slider.grid(row=row, column=1, sticky="ew", padx=5)

        return var

    @staticmethod
    def _format_val(val, fmt):
        if fmt == "pct":
            return f"{val:.0f}%"
        elif fmt == "gbp":
            return f"£{val:,.0f}"
        elif fmt == "gbp2":
            return f"£{val:,.2f}"
        elif fmt == "hrs":
            return f"{val:.1f}h"
        elif fmt == "int":
            return f"{int(val)}"
        elif fmt == "yrs":
            return f"{int(val)} yrs"
        elif fmt == "min":
            return f"{val:.0f} min"
        else:
            return f"{val:.1f}"

    def _build_controls(self, parent):
        row = 0

        # --- Title ---
        ttk.Label(parent, text="Car Park Simulation Controls",
                  style="Header.TLabel").grid(row=row, column=0, columnspan=3, pady=(0, 10))
        row += 1

        # --- Occupancy & Duration ---
        ttk.Label(parent, text="Occupancy & Duration", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(10, 5))
        row += 1

        self._make_slider(parent, "Occupancy Rate", 0, 100, 70, 1,
                          row, "occupancy_rate", "pct")
        row += 1
        self._make_slider(parent, "Avg Stay (hours)", 0.5, 11, 2.5, 0.5,
                          row, "avg_stay_hours", "hrs")
        row += 1
        self._make_slider(parent, "Dead Time (mins)", 0, 30, 10, 1,
                          row, "dead_time_minutes", "min")
        row += 1
        self._make_slider(parent, "Operating Days/Week", 1, 7, 6, 1,
                          row, "days_per_week", "int")
        row += 1

        # --- Vehicle Mix ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="Vehicle Mix (auto-normalised)", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        self._make_slider(parent, "Small Cars %", 0, 100, 60, 1,
                          row, "pct_small_car", "pct")
        row += 1
        self._make_slider(parent, "4x4 / Long Cars %", 0, 100, 20, 1,
                          row, "pct_large_car", "pct")
        row += 1
        self._make_slider(parent, "Small/Med Vans %", 0, 100, 15, 1,
                          row, "pct_small_van", "pct")
        row += 1
        self._make_slider(parent, "Large Vans %", 0, 100, 5, 1,
                          row, "pct_large_van", "pct")
        row += 1

        self.mix_info = ttk.Label(parent, text="", foreground="#89b4fa")
        self.mix_info.grid(row=row, column=0, columnspan=3, sticky="w")
        row += 1

        # --- Staff ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="Staffing", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        self._make_slider(parent, "Number of Staff", 0, 5, 1, 1,
                          row, "num_staff", "int")
        row += 1
        self._make_slider(parent, "Hourly Wage (£)", 8, 25, 12, 0.5,
                          row, "hourly_wage", "gbp2")
        row += 1
        self._make_slider(parent, "Employer NI %", 0, 20, 13.8, 0.1,
                          row, "employer_ni_pct", "pct")
        row += 1
        self._make_slider(parent, "Employer Pension %", 0, 10, 3, 0.5,
                          row, "employer_pension_pct", "pct")
        row += 1

        # --- ANPR ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="ANPR System", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        self.vars["anpr_enabled"] = tk.BooleanVar(value=False)
        anpr_cb = ttk.Checkbutton(parent, text="Enable ANPR (replaces all staff)",
                                  variable=self.vars["anpr_enabled"],
                                  command=self._update_results)
        anpr_cb.grid(row=row, column=0, columnspan=3, sticky="w")
        row += 1

        self._make_slider(parent, "Install Cost (£)", 5000, 50000, 15000, 1000,
                          row, "anpr_install", "gbp")
        row += 1
        self._make_slider(parent, "Monthly Maintenance (£)", 50, 1000, 200, 10,
                          row, "anpr_monthly", "gbp")
        row += 1
        self._make_slider(parent, "Amortise Over (years)", 1, 10, 5, 1,
                          row, "anpr_years", "yrs")
        row += 1

        # --- Overnight ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="Overnight Parking", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        self._make_slider(parent, "Overnight Cars", 0, 30, 0, 1,
                          row, "overnight_cars", "int")
        row += 1
        self._make_slider(parent, "Overnight Fee (£)", 5, 50, 15, 1,
                          row, "overnight_fee", "gbp")
        row += 1

        # --- Fixed Costs ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="Monthly Fixed Costs", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        self._make_slider(parent, "Rent (£/month)", 0, 10000, 2000, 100,
                          row, "monthly_rent", "gbp")
        row += 1
        self._make_slider(parent, "Insurance (£/month)", 0, 2000, 300, 50,
                          row, "monthly_insurance", "gbp")
        row += 1
        self._make_slider(parent, "Utilities (£/month)", 0, 1000, 150, 10,
                          row, "monthly_utilities", "gbp")
        row += 1
        self._make_slider(parent, "Maintenance (£/month)", 0, 1000, 200, 10,
                          row, "monthly_maintenance", "gbp")
        row += 1
        self._make_slider(parent, "Business Rates (£/month)", 0, 3000, 800, 50,
                          row, "monthly_business_rates", "gbp")
        row += 1
        self._make_slider(parent, "Cleaning (£/month)", 0, 500, 100, 10,
                          row, "monthly_cleaning", "gbp")
        row += 1
        self._make_slider(parent, "Card Processing Fee %", 0, 5, 2.5, 0.1,
                          row, "card_processing_fee_pct", "pct")
        row += 1

        # --- Pricing Overrides ---
        ttk.Separator(parent, orient="horizontal").grid(
            row=row, column=0, columnspan=3, sticky="ew", pady=10)
        row += 1
        ttk.Label(parent, text="Pricing (£/hour | £/day)", style="SubHeader.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", pady=(0, 5))
        row += 1

        for vtype, defaults in [
            (VehicleType.SMALL_CAR, (5, 25)),
            (VehicleType.LARGE_CAR_4X4, (6, 30)),
            (VehicleType.SMALL_MEDIUM_VAN, (6, 30)),
            (VehicleType.LARGE_VAN, (10, 50)),
        ]:
            name = vtype.value
            key_h = f"price_hourly_{vtype.name}"
            key_d = f"price_daily_{vtype.name}"

            ttk.Label(parent, text=f"{name}:").grid(row=row, column=0, sticky="w", pady=1)
            row += 1
            self._make_slider(parent, "  Hourly", 1, 20, defaults[0], 0.5,
                              row, key_h, "gbp2")
            row += 1
            self._make_slider(parent, "  Daily", 5, 100, defaults[1], 1,
                              row, key_d, "gbp")
            row += 1

    def _build_results(self, parent):
        """Build the results panel."""
        ttk.Label(parent, text="Simulation Results",
                  style="Header.TLabel").grid(row=0, column=0, columnspan=2, pady=(0, 10))

        self.result_labels = {}
        sections = [
            ("Capacity & Throughput", "SubHeader.TLabel", [
                ("effective_daytime_spaces", "Daytime Spaces Available"),
                ("vehicles_per_day", "Vehicles per Day"),
                ("turnover_rate", "Turnover per Space"),
                ("avg_revenue_per_vehicle", "Avg Revenue / Vehicle"),
            ]),
            ("Daily Revenue", "SubHeader.TLabel", [
                ("daily_parking_revenue_gross", "Parking (gross inc. VAT)"),
                ("daily_overnight_revenue_gross", "Overnight (gross)"),
                ("daily_total_revenue_gross", "Total Gross Revenue"),
                ("daily_vat_liability", "VAT Liability (20%)"),
                ("daily_card_fees", "Card Processing Fees"),
                ("daily_total_revenue_net", "NET Revenue (yours to keep)"),
            ]),
            ("Daily Costs", "SubHeader.TLabel", [
                ("daily_staff_cost", "Staff Wages"),
                ("daily_employer_ni", "Employer NI"),
                ("daily_employer_pension", "Employer Pension"),
                ("daily_anpr_cost", "ANPR Cost"),
                ("daily_rent", "Rent"),
                ("daily_insurance", "Insurance"),
                ("daily_utilities", "Utilities"),
                ("daily_maintenance", "Maintenance"),
                ("daily_business_rates", "Business Rates"),
                ("daily_cleaning", "Cleaning"),
                ("daily_total_cost", "TOTAL COST"),
            ]),
            ("Daily Profit", "SubHeader.TLabel", [
                ("daily_profit", "DAILY PROFIT"),
            ]),
            ("Weekly", "SubHeader.TLabel", [
                ("weekly_revenue", "Net Revenue"),
                ("weekly_cost", "Cost"),
                ("weekly_profit", "PROFIT"),
            ]),
            ("Monthly", "SubHeader.TLabel", [
                ("monthly_revenue", "Net Revenue"),
                ("monthly_cost", "Cost"),
                ("staff_monthly_total", "Staff Total (inc NI/pension)"),
                ("anpr_monthly_total", "ANPR Total"),
                ("monthly_profit", "PROFIT"),
            ]),
            ("Yearly", "SubHeader.TLabel", [
                ("yearly_revenue", "Net Revenue"),
                ("yearly_cost", "Cost"),
                ("yearly_profit", "PROFIT"),
            ]),
            ("Analysis", "SubHeader.TLabel", [
                ("break_even_occupancy", "Break-even Occupancy"),
            ]),
        ]

        row = 1
        for section_title, style, items in sections:
            ttk.Separator(parent, orient="horizontal").grid(
                row=row, column=0, columnspan=2, sticky="ew", pady=5)
            row += 1
            ttk.Label(parent, text=section_title, style=style).grid(
                row=row, column=0, columnspan=2, sticky="w", pady=(5, 2))
            row += 1
            for key, label_text in items:
                ttk.Label(parent, text=label_text).grid(row=row, column=0, sticky="w", padx=(10, 5))
                lbl = ttk.Label(parent, text="£0.00", style="Result.TLabel", width=18, anchor="e")
                lbl.grid(row=row, column=1, sticky="e")
                self.result_labels[key] = lbl
                row += 1

    # ------------------------------------------------------------ Update
    def _update_results(self, *_args):
        """Read all slider values, run simulation, update result labels."""
        from models import PricingTier

        cfg = CarParkConfig(
            total_spaces=64,
            operating_hours=11.0,
            opening_days_per_week=int(self.vars["days_per_week"].get()),
            occupancy_rate=self.vars["occupancy_rate"].get(),
            avg_stay_hours=self.vars["avg_stay_hours"].get(),
            dead_time_minutes=self.vars["dead_time_minutes"].get(),
            pct_small_car=self.vars["pct_small_car"].get(),
            pct_large_car=self.vars["pct_large_car"].get(),
            pct_small_van=self.vars["pct_small_van"].get(),
            pct_large_van=self.vars["pct_large_van"].get(),
            staff=StaffConfig(
                num_staff=int(self.vars["num_staff"].get()),
                hourly_wage=self.vars["hourly_wage"].get(),
                employer_ni_pct=self.vars["employer_ni_pct"].get(),
                employer_pension_pct=self.vars["employer_pension_pct"].get(),
            ),
            anpr=ANPRConfig(
                enabled=self.vars["anpr_enabled"].get(),
                install_cost=self.vars["anpr_install"].get(),
                monthly_maintenance=self.vars["anpr_monthly"].get(),
                amortise_years=max(1, int(self.vars["anpr_years"].get())),
            ),
            overnight=OvernightConfig(
                num_overnight_cars=int(self.vars["overnight_cars"].get()),
                overnight_flat_fee=self.vars["overnight_fee"].get(),
            ),
            monthly_rent=self.vars["monthly_rent"].get(),
            monthly_insurance=self.vars["monthly_insurance"].get(),
            monthly_utilities=self.vars["monthly_utilities"].get(),
            monthly_maintenance=self.vars["monthly_maintenance"].get(),
            monthly_business_rates=self.vars["monthly_business_rates"].get(),
            monthly_cleaning=self.vars["monthly_cleaning"].get(),
            card_processing_fee_pct=self.vars["card_processing_fee_pct"].get(),
        )

        # Update pricing from sliders
        for vtype in VehicleType:
            key_h = f"price_hourly_{vtype.name}"
            key_d = f"price_daily_{vtype.name}"
            cfg.pricing[vtype] = PricingTier(
                vehicle_type=vtype,
                hourly_rate=self.vars[key_h].get(),
                daily_rate=self.vars[key_d].get(),
            )

        # Vehicle mix info (show normalised values)
        raw_total = (cfg.pct_small_car + cfg.pct_large_car +
                     cfg.pct_small_van + cfg.pct_large_van)
        if raw_total > 0:
            self.mix_info.config(
                text=f"Raw sum: {raw_total:.0f}% → normalised to 100%",
                foreground="#89b4fa"
            )
        else:
            self.mix_info.config(text="⚠ All zero — defaulting to 100% small cars",
                                foreground="#f38ba8")

        # Run simulation
        result = run_simulation(cfg)

        # Format results
        money_fields = {
            "daily_parking_revenue_gross", "daily_overnight_revenue_gross",
            "daily_total_revenue_gross", "daily_vat_liability", "daily_card_fees",
            "daily_total_revenue_net",
            "daily_staff_cost", "daily_employer_ni", "daily_employer_pension",
            "daily_anpr_cost", "daily_rent", "daily_insurance",
            "daily_utilities", "daily_maintenance", "daily_business_rates",
            "daily_cleaning", "daily_total_cost", "daily_profit",
            "weekly_revenue", "weekly_cost", "weekly_profit",
            "monthly_revenue", "monthly_cost", "monthly_profit",
            "yearly_revenue", "yearly_cost", "yearly_profit",
            "avg_revenue_per_vehicle", "staff_monthly_total", "anpr_monthly_total",
        }
        pct_fields = {"break_even_occupancy"}
        float_fields = {"vehicles_per_day", "turnover_rate"}
        int_fields = {"effective_daytime_spaces"}
        profit_fields = {"daily_profit", "weekly_profit", "monthly_profit", "yearly_profit"}
        cost_highlight = {"daily_vat_liability", "daily_card_fees", "daily_total_cost"}

        for key, lbl in self.result_labels.items():
            val = getattr(result, key, 0)
            if key in money_fields:
                text = f"£{val:,.2f}"
            elif key in pct_fields:
                text = f"{val:.1f}%"
            elif key in float_fields:
                text = f"{val:.1f}"
            elif key in int_fields:
                text = f"{int(val)}"
            else:
                text = f"{val}"

            if key in profit_fields:
                lbl.configure(style="Result.TLabel" if val >= 0 else "Loss.TLabel",
                              font=("Helvetica", 11, "bold"))
            elif key in cost_highlight:
                lbl.configure(style="Loss.TLabel", font=("Helvetica", 10, ""))
            else:
                lbl.configure(style="Neutral.TLabel", font=("Helvetica", 10, ""))

            lbl.config(text=text)
